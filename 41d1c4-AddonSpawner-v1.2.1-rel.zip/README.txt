Requirements
============
GTA V (v1.0.877.1 or later)
ScriptHookV

Installation
============
Put AddonSpawner.asi and the AddonSpawner folder in the main GTA V folder.

Usage
=====
Press F5 to show the menu.

Add image previews:
Put a png or jpg image inside AddonSpawner/img, with the file name being the
spawn name of the vehicle. Recommended: png, 480x270. Any other aspect ratio
also works. Try keeping the file small for better performance.

Changing hotkey
===============
Change MenuKey in settings_menu.ini to something else. Available keys are
in Keyboard_Keys.txt

You can also assign a controller key combo to open the menu. 
settings_menu.ini should contain all info you need.

Source
======
https://github.com/E66666666/GTAVAddonLoader

